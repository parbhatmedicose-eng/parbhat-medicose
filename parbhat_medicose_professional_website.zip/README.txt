PARBHAT MEDICOSE FREE WEBSITE
Open index.html in a browser to preview it.

To publish it free, upload index.html to a static hosting service such as GitHub Pages or Netlify.
Replace/add images later if you want a product gallery.
